from __future__ import annotations
import numpy as np
from numpy.linalg import inv, det, slogdet


from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px


from scipy.stats import norm, multivariate_normal

SAMPLES_NUM = 1000
GAP = 10


class UnivariateGaussian:
    """
    Class for univariate Gaussian Distribution Estimator
    """

    def __init__(self, biased_var: bool = True) -> UnivariateGaussian:
        """
        Estimator for univariate Gaussian mean and variance parameters

        Parameters
        ----------
        biased_var : bool, default=True
            Should fitted estimator of variance be a biased or unbiased estimator

        Attributes
        ----------
        fitted_ : bool
            Initialized as false indicating current estimator instance has not been fitted.
            To be set as True in `UnivariateGaussian.fit` function.

        mu_: float
            Estimated expectation initialized as None. To be set in `UnivariateGaussian.fit`
            function.

        var_: float
            Estimated variance initialized as None. To be set in `UnivariateGaussian.fit`
            function.
        """
        self.biased_ = biased_var

        self.fitted_, self.mu_, self.var_ = False, None, None

    def fit(self, X: np.ndarray) -> UnivariateGaussian:
        """
        Estimate Gaussian expectation and variance from given samples

        Parameters
        ----------
        X: ndarray of shape (n_samples, )
            Training data

        Returns
        -------
        self : returns an instance of self.

        Notes
        -----
        Sets `self.mu_`, `self.var_` attributes according to calculated estimation (where
        estimator is either biased or unbiased). Then sets `self.fitted_` attribute to `True`
        """

        self.mu_ = np.average(X)

        var_array = np.ndarray.copy(X)
        var_array = np.subtract(var_array, np.full(X.size, self.mu_))
        var_array = np.square(var_array)

        self.var_ = (1 / (X.size - 1)) * np.sum(var_array)

        self.fitted_ = True
        return self

    def pdf(self, X: np.ndarray) -> np.ndarray:
        """
        Calculate PDF of observations under Gaussian model with fitted estimators

        Parameters
        ----------
        X: ndarray of shape (n_samples, )
            Samples to calculate PDF for

        Returns
        -------
        pdfs: ndarray of shape (n_samples, )
            Calculated values of given samples for PDF function of N(mu_, var_)

        Raises
        ------
        ValueError: In case function was called prior fitting the model
        """
        if not self.fitted_:
            raise ValueError("Estimator must first be fitted before calling `pdf` function")

        return norm(self.mu_, self.var_).pdf(X)

    @staticmethod
    def log_likelihood(mu: float, sigma: float, X: np.ndarray) -> float:
        """
        Calculate the log-likelihood of the data under a specified Gaussian model

        Parameters
        ----------
        mu : float
            Expectation of Gaussian
        sigma : float
            Variance of Gaussian
        X : ndarray of shape (n_samples, )
            Samples to calculate log-likelihood with

        Returns
        -------
        log_likelihood: float
            log-likelihood calculated
        """

        return np.log(multivariate_normal.pdf(X, mu, sigma)).sum()


class MultivariateGaussian:
    """
    Class for multivariate Gaussian Distribution Estimator
    """

    def __init__(self):
        """
        Initialize an instance of multivariate Gaussian estimator

        Attributes
        ----------
        fitted_ : bool
            Initialized as false indicating current estimator instance has not been fitted.
            To be set as True in `MultivariateGaussian.fit` function.

        mu_: float
            Estimated expectation initialized as None. To be set in `MultivariateGaussian.ft`
            function.

        cov_: float
            Estimated covariance initialized as None. To be set in `MultivariateGaussian.ft`
            function.
        """
        self.mu_, self.cov_ = None, None
        self.fitted_ = False

    def fit(self, X: np.ndarray) -> MultivariateGaussian:
        """
        Estimate Gaussian expectation and covariance from given samples

        Parameters
        ----------
        X: ndarray of shape (n_samples, )
            Training data

        Returns
        -------
        self : returns an instance of self.

        Notes
        -----
        Sets `self.mu_`, `self.cov_` attributes according to calculated estimation.
        Then sets `self.fitted_` attribute to `True`
        """
        self.mu_ = np.average(X, axis=0)

        self.cov_ = self.calculate_cov(X, self.mu_)
        return self

    @staticmethod
    def calculate_cov(X: np.ndarray, mu):
        """
        caculates the covariance according to given data and mu
        :param X: the data
        :param mu: the mu
        :return: the covariance
        """

        # var_array = np.subtract(var_array, np.full(shape=(len(X), 4), fill_value=mu))

        mat = np.zeros(shape=(4, 4))

        for i in range(0, 4):
            for j in range(0, 4):
                for k in range(len(X)):
                    mat[i, j] += (X[k, i] - mu[i]) * (X[k, j] - mu[j])

        return (1 / (len(X) - 1)) * mat

    def pdf(self, X: np.ndarray):
        """
        Calculate PDF of observations under Gaussian model with fitted estimators

        Parameters
        ----------
        X: ndarray of shape (n_samples, )
            Samples to calculate PDF for

        Returns
        -------
        pdfs: ndarray of shape (n_samples, )
            Calculated values of given samples for PDF function of N(mu_, cov_)

        Raises
        ------
        ValueError: In case function was called prior fitting the model
        """
        if not self.fitted_:
            raise ValueError("Estimator must first be fitted before calling `pdf` function")
        raise multivariate_normal(X, mean=self.mu_, cov=self.cov_).pdf(X)

    @staticmethod
    def log_likelihood(mu: np.ndarray, cov: np.ndarray, X: np.ndarray) -> float:
        """
        Calculate the log-likelihood of the data under a specified Gaussian model

        Parameters
        ----------
        mu : float
            Expectation of Gaussian
        cov : float
            covariance matrix of Gaussian
        X : ndarray of shape (n_samples, )
            Samples to calculate log-likelihood with

        Returns
        -------
        log_likelihood: float
            log-likelihood calculated
        """
        num = np.log(multivariate_normal.pdf(X, mu, cov)).sum()
        return num


class Ex1:
    def __init__(self):
        self.X = np.random.normal(10, 1, 1000)
        self.Y = np.random.multivariate_normal([0, 0, 4, 0],
                                               [[1, 0.2, 0, 0.5], [0.2, 2, 0, 0], [0, 0, 1, 0], [0.5, 0, 0, 1]], 1000)

        self.ug = UnivariateGaussian()
        self.mg = MultivariateGaussian()

    @staticmethod
    def plot(X, Y, title, xaxis, yaxis, mode):
        """
        plotting a graph
        :param X:
        :param Y:
        :param title:
        :param xaxis:
        :param yaxis:
        :param mode:
        :return:
        """
        fig = make_subplots(rows=1, cols=1) \
            .add_traces([go.Scatter(x=X, y=Y, mode=mode, marker=dict(color="black"), showlegend=False)],
                        rows=1, cols=1)

        fig.update_layout(title_text=title, height=500)

        # Update xaxis properties
        fig.update_xaxes(title_text=xaxis, row=1, col=1)

        # Update yaxis properties
        fig.update_yaxes(title_text=yaxis, row=1, col=1)
        fig.show()

    @staticmethod
    def plot_heatmap(X, Y, Color, title, xaxis, yaxis, color_name):
        """
        plotting a graph
        :param X:
        :param Y:
        :param title:
        :param xaxis:
        :param yaxis:
        :param color
        :return:
        """
        fig = px.imshow([X, Y, Color])

        fig.update_layout(title_text=title, height=500)

        fig.show()

    def Q1(self):
        """
        answer for question 1
        :return:
        """
        self.ug.fit(self.X)

        print("(" + str(self.ug.mu_) + ", " + str(self.ug.var_) + ")")

    def Q2(self):
        """
        answer for question 2
        :return:
        """
        samples = [self.ug.fit(np.random.choice(self.X, i)).mu_ for i in range(GAP, SAMPLES_NUM, GAP)]

        distance = [abs(10 - sample) for sample in samples]
        t = r"$\text{(1)Distance Between Estimated and True Value of the Expectation as a Function of the Sample Size}$"
        xaxis = "Size of Samples"
        yaxis = "Distance"

        self.plot([i for i in range(GAP, SAMPLES_NUM, GAP)], distance, t, xaxis, yaxis, 'lines')

    def Q3(self):
        """
        answer for question 3
        :return:
        """
        self.ug.fit(self.X)
        real = self.ug.pdf(self.X)
        t = r"$\text{(2)the empirical PDF function under the fitted model}$"
        xaxis = "The Random Samples"
        yaxis = "The PDF Results"
        self.plot(self.X, real, t, xaxis, yaxis, 'markers')

    def Q4(self):
        """
        answer for question 4
        :return:
        """
        self.mg.fit(self.Y)

        print(self.mg.mu_, "\n", self.mg.cov_)

    def Q5(self):
        """
        answer for question 5
        :return:
        """
        self.mg.fit(self.Y)
        f1 = np.linspace(-10, 10, 2000)
        f3 = np.linspace(-10, 10, 2000)
        log_likelihood = []

        for i in range(2000):
            mu = np.array([f1[i], 0, f3[i], 0], dtype=float)
            cov = MultivariateGaussian.calculate_cov(self.Y, mu)
            log_likelihood.append(MultivariateGaussian.log_likelihood(mu, cov, self.Y))

        self.plot_heatmap(f1, f3, log_likelihood, "Heatmap Graph for Log-Likelihood",
                          "f1", "f3", "Log-Likelihood")

    def Quiz_3(self):
        arr = np.array([1, 5, 2, 3, 8, -4, -2, 5, 1, 10, -10, 4, 5, 2, 7, 1, 1, 3, 2, -1, -3, 1, -4, 1, 2, 1,
                  -4, -4, 1, 3, 2, 6, -6, 8, 3, -6, 4, 1, -2, 3, 1, 4, 1, 4, -2, 3, -1, 0, 3, 5, 0, -2])
        print("option 1:", UnivariateGaussian.log_likelihood(1, 1, arr))
        print("option 2:", UnivariateGaussian.log_likelihood(10, 1, arr))


if __name__ == '__main__':
    np.random.seed(0)
    ex1 = Ex1()
    ex1.Q1()
    ex1.Q2()
    ex1.Q3()
    ex1.Q4()
    ex1.Q5()
    ex1.Quiz_3()
    np.array([1, 5, 2, 3, 8, -4, -2, 5, 1, 10, -10, 4, 5, 2, 7, 1, 1, 3, 2, -1, -3, 1, -4, 1, 2, 1,
              -4, -4, 1, 3, 2, 6, -6, 8, 3, -6, 4, 1, -2, 3, 1, 4, 1, 4, -2, 3, -1, 0, 3, 5, 0, -2])









